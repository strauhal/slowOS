//! Text editor widget for SlowWrite
//! 
//! Handles cursor movement, selection, and text rendering.
//! Uses egui's text layout system for proper proportional font kerning.
//! No fixed char_width grid — every character position is measured
//! through the font system so kerning and variable widths work correctly.

use crate::document::Document;
use egui::{FontId, Pos2, Rect, Response, Sense, Stroke, Ui, Vec2};
use slowcore::theme::SlowColors;

/// Cursor position in the document
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Cursor {
    /// Character position in document
    pub pos: usize,
    /// Selection anchor (if selecting)
    pub anchor: Option<usize>,
}

impl Cursor {
    pub fn new(pos: usize) -> Self {
        Self { pos, anchor: None }
    }
    
    /// Start a selection from current position
    pub fn start_selection(&mut self) {
        if self.anchor.is_none() {
            self.anchor = Some(self.pos);
        }
    }
    
    /// Clear selection
    pub fn clear_selection(&mut self) {
        self.anchor = None;
    }
    
    /// Get selection range (start, end)
    pub fn selection_range(&self) -> Option<(usize, usize)> {
        self.anchor.map(|anchor| {
            if anchor < self.pos {
                (anchor, self.pos)
            } else {
                (self.pos, anchor)
            }
        })
    }
    
    /// Check if there's an active selection
    pub fn has_selection(&self) -> bool {
        self.anchor.is_some() && self.anchor != Some(self.pos)
    }
}

/// Editor state and rendering
pub struct Editor {
    pub cursor: Cursor,
    /// Scroll offset in pixels
    pub scroll_offset: Vec2,
    /// Line height in pixels
    pub line_height: f32,
    /// Font size for body text
    pub font_size: f32,
    /// Left margin for line numbers
    pub left_margin: f32,
    /// Whether cursor is visible (for blinking)
    pub cursor_visible: bool,
    /// Timer for cursor blink
    cursor_blink_time: f64,
    /// Find/replace state
    pub find_query: String,
    pub replace_query: String,
    pub find_results: Vec<(usize, usize)>,
    pub current_find_index: Option<usize>,
}

impl Default for Editor {
    fn default() -> Self {
        Self::new()
    }
}

impl Editor {
    pub fn new() -> Self {
        Self {
            cursor: Cursor::default(),
            scroll_offset: Vec2::ZERO,
            line_height: 22.0,
            font_size: 14.0,
            left_margin: 50.0,
            cursor_visible: true,
            cursor_blink_time: 0.0,
            find_query: String::new(),
            replace_query: String::new(),
            find_results: Vec::new(),
            current_find_index: None,
        }
    }
    
    // ---------------------------------------------------------------
    // Text measurement helpers — proportional font aware
    // ---------------------------------------------------------------
    
    /// Measure the pixel x-offset of a character boundary in a line.
    /// char_idx=0 returns 0, char_idx=len returns the full line width.
    /// Creates a galley of the prefix substring for accurate kerning.
    fn measure_char_x(ctx: &egui::Context, text: &str, char_idx: usize, font: &FontId) -> f32 {
        if char_idx == 0 || text.is_empty() {
            return 0.0;
        }
        let prefix: String = text.chars().take(char_idx).collect();
        ctx.fonts(|f| f.layout_no_wrap(prefix, font.clone(), SlowColors::BLACK)).size().x
    }
    
    /// Find the character boundary closest to a given x pixel position.
    /// Returns the character index (0 to text.chars().count()).
    fn x_to_char(ctx: &egui::Context, text: &str, target_x: f32, font: &FontId) -> usize {
        if text.is_empty() || target_x <= 0.0 {
            return 0;
        }
        let chars: Vec<char> = text.chars().collect();
        let mut prev_x = 0.0f32;
        
        for i in 1..=chars.len() {
            let prefix: String = chars[..i].iter().collect();
            let curr_x = ctx.fonts(|f| {
                f.layout_no_wrap(prefix, font.clone(), SlowColors::BLACK)
            }).size().x;
            
            if curr_x >= target_x {
                // Snap to whichever boundary is closer
                let mid = (prev_x + curr_x) / 2.0;
                return if target_x < mid { i - 1 } else { i };
            }
            prev_x = curr_x;
        }
        chars.len()
    }
    
    // ---------------------------------------------------------------
    // Cursor movement
    // ---------------------------------------------------------------
    
    /// Move cursor left
    pub fn move_left(&mut self, _doc: &Document, select: bool) {
        if select {
            self.cursor.start_selection();
        } else {
            if let Some((start, _)) = self.cursor.selection_range() {
                self.cursor.pos = start;
                self.cursor.clear_selection();
                return;
            }
        }
        
        if self.cursor.pos > 0 {
            self.cursor.pos -= 1;
        }
        
        if !select {
            self.cursor.clear_selection();
        }
    }
    
    /// Move cursor right
    pub fn move_right(&mut self, doc: &Document, select: bool) {
        if select {
            self.cursor.start_selection();
        } else {
            if let Some((_, end)) = self.cursor.selection_range() {
                self.cursor.pos = end;
                self.cursor.clear_selection();
                return;
            }
        }
        
        if self.cursor.pos < doc.char_count() {
            self.cursor.pos += 1;
        }
        
        if !select {
            self.cursor.clear_selection();
        }
    }
    
    /// Move cursor up one line
    pub fn move_up(&mut self, doc: &Document, select: bool) {
        if select {
            self.cursor.start_selection();
        }
        
        let (line, col) = doc.char_to_line_col(self.cursor.pos);
        if line > 0 {
            self.cursor.pos = doc.line_col_to_char(line - 1, col);
        }
        
        if !select {
            self.cursor.clear_selection();
        }
    }
    
    /// Move cursor down one line
    pub fn move_down(&mut self, doc: &Document, select: bool) {
        if select {
            self.cursor.start_selection();
        }
        
        let (line, col) = doc.char_to_line_col(self.cursor.pos);
        if line < doc.line_count().saturating_sub(1) {
            self.cursor.pos = doc.line_col_to_char(line + 1, col);
        }
        
        if !select {
            self.cursor.clear_selection();
        }
    }
    
    /// Move to start of line
    pub fn move_to_line_start(&mut self, doc: &Document, select: bool) {
        if select {
            self.cursor.start_selection();
        }
        
        let (line, _) = doc.char_to_line_col(self.cursor.pos);
        self.cursor.pos = doc.line_col_to_char(line, 0);
        
        if !select {
            self.cursor.clear_selection();
        }
    }
    
    /// Move to end of line
    pub fn move_to_line_end(&mut self, doc: &Document, select: bool) {
        if select {
            self.cursor.start_selection();
        }
        
        let (line, _) = doc.char_to_line_col(self.cursor.pos);
        if let Some(line_content) = doc.line(line) {
            let line_len = line_content.trim_end_matches('\n').chars().count();
            self.cursor.pos = doc.line_col_to_char(line, line_len);
        }
        
        if !select {
            self.cursor.clear_selection();
        }
    }
    
    /// Move word left
    pub fn move_word_left(&mut self, doc: &Document, select: bool) {
        if select {
            self.cursor.start_selection();
        }
        
        let text = doc.content.to_string();
        let chars: Vec<char> = text.chars().collect();
        let mut pos = self.cursor.pos;
        
        // Skip whitespace backwards
        while pos > 0 && chars.get(pos - 1).map(|c| c.is_whitespace()).unwrap_or(false) {
            pos -= 1;
        }
        
        // Skip word characters backwards
        while pos > 0 && chars.get(pos - 1).map(|c| !c.is_whitespace()).unwrap_or(false) {
            pos -= 1;
        }
        
        self.cursor.pos = pos;
        
        if !select {
            self.cursor.clear_selection();
        }
    }
    
    /// Move word right
    pub fn move_word_right(&mut self, doc: &Document, select: bool) {
        if select {
            self.cursor.start_selection();
        }
        
        let text = doc.content.to_string();
        let chars: Vec<char> = text.chars().collect();
        let len = chars.len();
        let mut pos = self.cursor.pos;
        
        // Skip word characters forward
        while pos < len && chars.get(pos).map(|c| !c.is_whitespace()).unwrap_or(false) {
            pos += 1;
        }
        
        // Skip whitespace forward
        while pos < len && chars.get(pos).map(|c| c.is_whitespace()).unwrap_or(false) {
            pos += 1;
        }
        
        self.cursor.pos = pos;
        
        if !select {
            self.cursor.clear_selection();
        }
    }
    
    /// Select all text
    pub fn select_all(&mut self, doc: &Document) {
        self.cursor.anchor = Some(0);
        self.cursor.pos = doc.char_count();
    }
    
    // ---------------------------------------------------------------
    // Editing
    // ---------------------------------------------------------------
    
    /// Insert text at cursor, handling selection
    pub fn insert_text(&mut self, doc: &mut Document, text: &str) {
        doc.save_undo_state(self.cursor.pos);
        
        if let Some((start, end)) = self.cursor.selection_range() {
            doc.delete_range(start, end);
            self.cursor.pos = start;
            self.cursor.clear_selection();
        }
        
        doc.insert(self.cursor.pos, text);
        self.cursor.pos += text.chars().count();
    }
    
    /// Delete character before cursor (backspace)
    pub fn backspace(&mut self, doc: &mut Document) {
        doc.save_undo_state(self.cursor.pos);
        
        if let Some((start, end)) = self.cursor.selection_range() {
            doc.delete_range(start, end);
            self.cursor.pos = start;
            self.cursor.clear_selection();
        } else if self.cursor.pos > 0 {
            self.cursor.pos -= 1;
            doc.delete(self.cursor.pos);
        }
    }
    
    /// Delete character at cursor (delete key)
    pub fn delete(&mut self, doc: &mut Document) {
        doc.save_undo_state(self.cursor.pos);
        
        if let Some((start, end)) = self.cursor.selection_range() {
            doc.delete_range(start, end);
            self.cursor.pos = start;
            self.cursor.clear_selection();
        } else {
            doc.delete(self.cursor.pos);
        }
    }
    
    /// Kill text from cursor to end of line (emacs Ctrl+K).
    /// Returns the killed text (for the kill ring / internal clipboard).
    pub fn kill_to_line_end(&mut self, doc: &mut Document) -> Option<String> {
        doc.save_undo_state(self.cursor.pos);
        let (line, col) = doc.char_to_line_col(self.cursor.pos);
        if let Some(line_content) = doc.line(line) {
            let line_len = line_content.trim_end_matches('\n').chars().count();
            if col < line_len {
                // Kill from cursor to end of visible line
                let end_pos = doc.line_col_to_char(line, line_len);
                let killed = doc.get_range(self.cursor.pos, end_pos);
                doc.delete_range(self.cursor.pos, end_pos);
                return Some(killed);
            } else if self.cursor.pos < doc.char_count() {
                // At end of line: kill the newline (join with next line)
                let killed = doc.get_range(self.cursor.pos, self.cursor.pos + 1);
                doc.delete(self.cursor.pos);
                return Some(killed);
            }
        }
        None
    }
    
    /// Get selected text
    pub fn selected_text(&self, doc: &Document) -> Option<String> {
        self.cursor.selection_range().map(|(start, end)| {
            doc.get_range(start, end)
        })
    }
    
    // ---------------------------------------------------------------
    // Find / Replace
    // ---------------------------------------------------------------
    
    pub fn find(&mut self, doc: &Document) {
        self.find_results = doc.find_all(&self.find_query);
        self.current_find_index = if self.find_results.is_empty() {
            None
        } else {
            Some(0)
        };
    }
    
    pub fn find_next(&mut self) {
        if !self.find_results.is_empty() {
            self.current_find_index = Some(
                self.current_find_index
                    .map(|i| (i + 1) % self.find_results.len())
                    .unwrap_or(0)
            );
            
            if let Some(idx) = self.current_find_index {
                let (start, end) = self.find_results[idx];
                self.cursor.anchor = Some(start);
                self.cursor.pos = end;
            }
        }
    }
    
    pub fn replace_current(&mut self, doc: &mut Document) {
        if let Some(idx) = self.current_find_index {
            if idx < self.find_results.len() {
                let (start, end) = self.find_results[idx];
                doc.save_undo_state(self.cursor.pos);
                doc.replace(start, end, &self.replace_query);
                self.find(doc);
            }
        }
    }
    
    pub fn replace_all(&mut self, doc: &mut Document) {
        if !self.find_results.is_empty() {
            doc.save_undo_state(self.cursor.pos);
            
            for (start, end) in self.find_results.iter().rev() {
                doc.replace(*start, *end, &self.replace_query);
            }
            
            self.find_results.clear();
            self.current_find_index = None;
        }
    }
    
    // ---------------------------------------------------------------
    // Cursor blink
    // ---------------------------------------------------------------
    
    pub fn update(&mut self, dt: f64) {
        self.cursor_blink_time += dt;
        if self.cursor_blink_time >= 0.5 {
            self.cursor_blink_time = 0.0;
            self.cursor_visible = !self.cursor_visible;
        }
    }
    
    pub fn reset_blink(&mut self) {
        self.cursor_visible = true;
        self.cursor_blink_time = 0.0;
    }
    
    // ---------------------------------------------------------------
    // Rendering — proportional font with proper kerning
    // ---------------------------------------------------------------
    
    /// Render the editor.
    ///
    /// Each line is drawn as a single text call through egui's font system,
    /// giving us proper kerning, ligatures, and variable character widths.
    /// Cursor and selection positions are computed by measuring prefix
    /// substrings through the same font system.
    pub fn render(&mut self, ui: &mut Ui, doc: &Document, rect: Rect) -> Response {
        let ctx = ui.ctx().clone();
        
        let response = ui.allocate_rect(rect, Sense::click_and_drag());
        let painter = ui.painter_at(rect);
        
        // Background
        painter.rect_filled(rect, 0.0, SlowColors::WHITE);
        painter.rect_stroke(rect, 0.0, Stroke::new(1.0, SlowColors::BLACK));
        
        let text_area = Rect::from_min_max(
            rect.min + Vec2::new(self.left_margin, 4.0),
            rect.max - Vec2::new(4.0, 4.0),
        );
        
        let font = FontId::proportional(self.font_size);
        
        // Visible line range
        let first_visible_line = (self.scroll_offset.y / self.line_height) as usize;
        let visible_lines = ((rect.height() / self.line_height) as usize) + 2;
        let last_visible_line = (first_visible_line + visible_lines).min(doc.line_count());
        
        // Separator between line numbers and text
        painter.vline(
            rect.min.x + self.left_margin - 2.0,
            rect.min.y..=rect.max.y,
            Stroke::new(1.0, SlowColors::BLACK),
        );
        
        for line_idx in first_visible_line..last_visible_line {
            let y = rect.min.y + (line_idx as f32 * self.line_height) - self.scroll_offset.y;
            
            if y < rect.min.y - self.line_height || y > rect.max.y {
                continue;
            }
            
            // Line number — right-aligned so digits line up with proportional font
            painter.text(
                Pos2::new(rect.min.x + self.left_margin - 8.0, y + self.line_height / 2.0),
                egui::Align2::RIGHT_CENTER,
                format!("{}", line_idx + 1),
                font.clone(),
                SlowColors::BLACK,
            );
            
            // Line content
            if let Some(line_content) = doc.line(line_idx) {
                let line_start_char = doc.content.line_to_char(line_idx);
                let line_display = line_content.trim_end_matches('\n');
                
                // Draw the FULL line as one text call — proper kerning!
                if !line_display.is_empty() {
                    painter.text(
                        Pos2::new(text_area.min.x, y + self.line_height / 2.0),
                        egui::Align2::LEFT_CENTER,
                        line_display,
                        font.clone(),
                        SlowColors::BLACK,
                    );
                }
                
                // Selection overlay (dithered pattern on top of text)
                if let Some((sel_start, sel_end)) = self.cursor.selection_range() {
                    let line_char_count = line_display.chars().count();
                    let line_end_char = line_start_char + line_char_count;
                    
                    if sel_end > line_start_char && sel_start < line_end_char {
                        let local_start = sel_start.max(line_start_char) - line_start_char;
                        let local_end = sel_end.min(line_end_char) - line_start_char;
                        
                        let x_start = Self::measure_char_x(&ctx, line_display, local_start, &font);
                        let x_end = Self::measure_char_x(&ctx, line_display, local_end, &font);
                        
                        slowcore::dither::draw_dither_selection(
                            &painter,
                            Rect::from_min_max(
                                Pos2::new(text_area.min.x + x_start, y),
                                Pos2::new(text_area.min.x + x_end, y + self.line_height),
                            ),
                        );
                    }
                }
            }
        }
        
        // Cursor
        if self.cursor_visible {
            let (cursor_line, cursor_col) = doc.char_to_line_col(self.cursor.pos);
            let cursor_y = rect.min.y + (cursor_line as f32 * self.line_height) - self.scroll_offset.y;
            
            if cursor_y >= rect.min.y && cursor_y <= rect.max.y - self.line_height {
                let line_text = doc.line(cursor_line)
                    .map(|l| l.trim_end_matches('\n').to_string())
                    .unwrap_or_default();
                
                let cursor_x = text_area.min.x
                    + Self::measure_char_x(&ctx, &line_text, cursor_col, &font);
                
                painter.vline(
                    cursor_x,
                    cursor_y..=cursor_y + self.line_height,
                    Stroke::new(2.0, SlowColors::BLACK),
                );
            }
        }
        
        // Click to position cursor
        if response.clicked() {
            if let Some(click_pos) = response.interact_pointer_pos() {
                let rel_y = click_pos.y - rect.min.y + self.scroll_offset.y;
                let line = ((rel_y / self.line_height) as usize)
                    .min(doc.line_count().saturating_sub(1));
                
                let rel_x = (click_pos.x - text_area.min.x).max(0.0);
                let line_text = doc.line(line)
                    .map(|l| l.trim_end_matches('\n').to_string())
                    .unwrap_or_default();
                
                let col = Self::x_to_char(&ctx, &line_text, rel_x, &font);
                
                self.cursor.pos = doc.line_col_to_char(line, col);
                self.cursor.clear_selection();
                self.reset_blink();
            }
        }
        
        response
    }
    
    /// Ensure cursor is visible by adjusting scroll
    pub fn ensure_cursor_visible(&mut self, doc: &Document, view_height: f32) {
        let (cursor_line, _) = doc.char_to_line_col(self.cursor.pos);
        let cursor_y = cursor_line as f32 * self.line_height;
        
        if cursor_y < self.scroll_offset.y {
            self.scroll_offset.y = cursor_y;
        }
        
        if cursor_y + self.line_height > self.scroll_offset.y + view_height {
            self.scroll_offset.y = cursor_y + self.line_height - view_height;
        }
    }
}
